<section class="pricing-sec">
  <img src="images/pricing-back.png" alt="pricing-back">
  <div class="container">
    <div class="pricing-title">
      <h4>Our Pricing</h4>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.ut labore.</p>
    </div>
    <div class="row">
      <div class="col-md-4">
        <div  class="pricing-blk">
          <h4>$35</h4>
          <h3>1 Month</h3>
          <h5>TOTAL PRICE $35.98</h5>
          <ul>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
          </ul>
          <a href="login.php">join now</a>
        </div>
      </div>
      <div class="col-md-4">
        <div  class="pricing-blk pricing-blks">
          <h4>$31.01</h4>
          <h3>3 Month</h3>
          <h5>TOTAL PRICE $31.01</h5>
          <ul>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
          </ul>
          <a href="login.php">join now</a>
        </div>
      </div>
      <div class="col-md-4">
        <div class="pricing-blk">
          <h4>$26.6</h4>
          <h3>12 Month</h3>
          <h5>TOTAL PRICE $26.6</h5>
          <ul>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
            <li>Lorem ipsum dolor sit amet,</li>
          </ul>
          <a href="login.php">join now</a>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="register-btn">
        <a href="">Register Here For All Discounts</a>
      </div>
    </div>
  </div>
</section>