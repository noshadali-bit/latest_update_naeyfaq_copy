<!-- <link rel="shortcut icon" href="{{asset('images/favicon.ico')}}" /> -->
  <link href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
  <link href="{{asset('web/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{asset('web/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
  <link href="{{asset('web/vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
  <link href="{{asset('web/vendor/glightbox/css/glightbox.min.css')}}" rel="stylesheet">
  <link href="{{asset('web/vendor/swiper/swiper-bundle.min.css')}}" rel="stylesheet">
  <link href="{{asset('web/vendor/aos/aos.css')}}" rel="stylesheet">
  <link href="{{asset('web/font/font.css')}}" rel="stylesheet">
  <link href="{{asset('web/vendor/swiper/swiper.css')}}" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

  <link href="{{asset('web/css/main.css')}}" rel="stylesheet"> </head>

@yield('link')