



<link rel="stylesheet" href="{{asset('web/css/bootstrap.min1.css')}}">

<link rel="stylesheet" href="{{asset('web/css/slick1.css')}}">

<link rel="stylesheet" href="{{asset('web/css/slick-theme1.css')}}">

<link rel="stylesheet" href="{{asset('web/css/fancybox.min1.css')}}">

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<link rel="stylesheet" href="{{asset('web/css/custom1.css')}}">

@yield('link')

